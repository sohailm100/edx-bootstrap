module.exports = {
  extends: '@edx/stylelint-config-edx',
  "rules": {
    "at-rule-empty-line-before": null,
    "function-no-unknown": null,
    "scss/no-global-function-names": null,
  }
};
