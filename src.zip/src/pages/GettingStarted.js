import React from 'react';

export default class GettingStarted extends React.Component {
  render() {
    return (
      <main className="col-12 col-md-9 col-xl-8 py-md-3 pl-md-5 bd-content" role="main">

        <h1 className="mt-5">Usage</h1>
        <p className="lead mb-5">Details on how to pull this into a project and get started.</p>

      </main>
    );
  }
}